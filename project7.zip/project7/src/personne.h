#include <gtk/gtk.h>
#include "callbacks.h"
#include "support.h"
#include "interface.h"
#include "login.h"
#include <string.h>
#include <stdio.h>

typedef struct
{
  char nom[50];
  char prenom[50];
  char date[50];
  char poids[50];
  char etat_medical[50];
  char cin[50]

}Personne;
void ajouter_personne(Personne p);
void afficher_personne(GtkWidget *liste);
void supprimer(char cin[],int n);
void modifier(Personne p);

typedef struct
{
  char jour[50];
  char heure[50];
}disp ;
void afficher_dispo(GtkWidget *liste);
void supprimer1(char jour[],int n);
