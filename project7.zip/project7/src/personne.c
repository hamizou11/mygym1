#include <stdio.h>
#include <gtk/gtk.h>
#include "personne.h"
#include <string.h>

enum
{
  NOM,
  PRENOM,
  CIN,
  DATE,
  POIDS,
  ETAT_MEDICAL,

  COLUMNS
};
/*void ajouter_personne(Personne p)
{
  FILE *f;
  f=fopen("/home/hamza/Projects/project7/src/adherant.txt","a+");
  if (f!=NULL)
  {
    fprintf(f,"%s %s %s %s %s-%s-%s \n",p.nom,p.prenom,p.poids,p.etat_medical,p.jour,p.mois,p.annee);
    fclose(f);
  }
}*/
void supprimer(char cin[],int n)
{
Personne p;
FILE*f;
FILE*f1;


f=fopen("adh.txt","a+");
f1=fopen("adh1.txt","a+");
if (f!=NULL)
{
while(fscanf(f,"%s %s %s %s %s %s\n",p.nom,p.prenom,p.cin,p.date,p.poids,p.etat_medical)!=EOF)
{
if(strcmp(cin,p.cin)!=0)
{
fprintf(f1,"%s %s %s %s %s %s\n",p.nom,p.prenom,p.cin,p.date,p.poids,p.etat_medical);
}


}
}
fclose(f);
fclose(f1);
remove("adh.txt");
rename("adh1.txt","adh.txt");

}
void supprimer1(char jour[],int n)
{
  disp d;
  FILE*f;
  FILE*f1;


  f=fopen("disp.txt","a+");
  f1=fopen("disp1.txt","a+");
  if (f!=NULL)
  {
  while(fscanf(f,"%s %s\n",d.jour,d.heure)!=EOF)
  {
  if(strcmp(jour,d.jour)!=0)
  {
  fprintf(f1,"%s %s\n",d.jour,d.heure);
  }


  }
  }
  fclose(f);
  fclose(f1);
  remove("disp.txt");
  rename("disp1.txt","disp.txt");
}

void modifier(Personne p)
{
  Personne c;
  FILE*f;
  FILE *f1;
  f=fopen("adh.txt","a+");
  f1=fopen("adh1.txt","a+");
  if(f!=NULL)
  {
    while(fscanf(f,"%s %s %s %s %s %s\n",c.nom,c.prenom,c.cin,c.date,c.poids,c.etat_medical)!=EOF)
    {
      if(strcmp(c.cin,p.cin)==0)
      {
        fprintf(f1,"%s %s %s %s %s %s\n",p.nom,p.prenom,p.cin,p.date,p.poids,p.etat_medical);
      }
      else fprintf(f1,"%s %s %s %s %s %s\n",c.nom,c.prenom,c.cin,c.date,c.poids,c.etat_medical);
    }
  }
  fclose(f);
  fclose(f1);
  remove("adh.txt");
  rename("adh1.txt","adh.txt");
}






void afficher_personne(GtkWidget *liste)
{
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkTreeIter iter;
  GtkListStore *store;
  char nom[50];
  char prenom[50];
  char date[50];
  char poids[50];
  char etat_medical[50];
  char cin[50];
  store=NULL;

  FILE *f;
  store=gtk_tree_view_get_model(liste);
  if (store==NULL)
  {

    renderer= gtk_cell_renderer_text_new();
    column= gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
    renderer= gtk_cell_renderer_text_new();
    column= gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",PRENOM,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
    renderer= gtk_cell_renderer_text_new();
    column= gtk_tree_view_column_new_with_attributes("cin",renderer,"text",CIN,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
    renderer= gtk_cell_renderer_text_new();
    column= gtk_tree_view_column_new_with_attributes("date",renderer,"text",DATE,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);




    renderer= gtk_cell_renderer_text_new();
    column= gtk_tree_view_column_new_with_attributes("poids",renderer,"text",POIDS,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

    renderer= gtk_cell_renderer_text_new();
    column= gtk_tree_view_column_new_with_attributes("etat_medical",renderer,"text",ETAT_MEDICAL,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
    renderer= gtk_cell_renderer_text_new();

  }
  store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
  f=fopen("/home/hamza/Projects/project7/src/adh.txt", "r");
  if (f==NULL)
  {
    return;
  }
  else
  {
    f= fopen("/home/hamza/Projects/project7/src/adh.txt", "a+");
    while(fscanf(f,"%s %s %s %s %s %s\n",nom,prenom,cin,date,poids,etat_medical)!=EOF)
    {
      gtk_list_store_append(store, &iter);
      gtk_list_store_set(store, &iter,NOM,nom,PRENOM,prenom,CIN,cin,DATE,date,POIDS,poids,ETAT_MEDICAL,etat_medical, -1);

    }
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref (store);
    }
  }
  enum
  {
    JOUR,
    HEURE,
    COLUMNS1
  };
void  afficher_dispo(GtkWidget *liste)
{
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkTreeIter iter;
  GtkListStore *store;
  char jour[50];
  char heure[50];

  store=NULL;

  FILE *f;
  store=gtk_tree_view_get_model(liste);
  if (store==NULL)
  {

    renderer= gtk_cell_renderer_text_new();
    column= gtk_tree_view_column_new_with_attributes("jour",renderer,"text",JOUR,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
    renderer= gtk_cell_renderer_text_new();
    column= gtk_tree_view_column_new_with_attributes("heure",renderer,"text",HEURE,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
    renderer= gtk_cell_renderer_text_new();




  }
  store=gtk_list_store_new(COLUMNS1,G_TYPE_STRING,G_TYPE_STRING);
  f=fopen("/home/hamza/Projects/project7/src/disp.txt", "r");
  if (f==NULL)
  {
    return;
  }
  else
  {
    f= fopen("/home/hamza/Projects/project7/src/disp.txt", "a+");
    while(fscanf(f,"%s %s\n",jour,heure)!=EOF)
    {
      gtk_list_store_append(store, &iter);
      gtk_list_store_set(store, &iter,JOUR,jour,HEURE,heure, -1);

    }
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref (store);
    }
}
