#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_modif_clicked                       (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_anuuler_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_sup_disp_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ajou_disp_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retour_disp_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ajout_dis_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
