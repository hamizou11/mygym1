#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "login.c"
#include <string.h>
#include <stdio.h>
#include "personne.c"


void

on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

  int n=150,check = -1;
     char b[70]="Bienvenue dans l'espace ";
     char c[50]="mot de passe ou login incorrect";
     GtkWidget *input1;
     GtkWidget *input2;
     GtkWidget *output1;
     GtkWidget *output2;
     GtkWidget *nutri2;
     GtkWidget *nutri1;


     nutri2=create_nutri2();
     input1=lookup_widget(objet_graphique, "entry1");
     input2=lookup_widget(objet_graphique, "entry2");
     output1=lookup_widget(objet_graphique, "label4");
     nutri1=lookup_widget(objet_graphique,"nutri1");
     char nom[20];
     strcpy(nom,gtk_entry_get_text(GTK_ENTRY(input1)));
     char pass[20];
     strcpy(pass,gtk_entry_get_text(GTK_ENTRY(input2)));
     check = check_user(nom,pass,n);
     if (check==0){
      gtk_widget_hide(nutri1);
     strcat(b,nom);
     gtk_widget_show(nutri2);
     output2=lookup_widget(nutri2, "label5");
     gtk_label_set_text(GTK_LABEL(output2),b);
     }else{
     gtk_label_set_text(GTK_LABEL(output1),c);
     }
}


void
on_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
gtk_main_quit();
}

void
on_button3_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *nutri2;
  GtkWidget *nutri3;
  nutri3=create_nutri3();
  nutri2=lookup_widget(objet_graphique,"nutri2");
  gtk_widget_hide(nutri2);
  gtk_widget_show(nutri3);


}

void
on_button4_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  char nom[50];char prenom[50];char jour[50];char mois[50];char annee[50];char poids [50];
  char etat_medical [50]; char cin[50];char date [50];

  GtkWidget *input4;
  GtkWidget *input5;
  GtkWidget *input1;
  GtkWidget * input6;
  GtkWidget *input7;
  GtkWidget *input8;
  GtkWidget *nutri3;
  nutri3=lookup_widget(objet_graphique,"nutri3");
FILE *f;

input4=lookup_widget(objet_graphique,"entryhamza");
input5=lookup_widget(objet_graphique,"entryhamza1");
input6=lookup_widget(objet_graphique,"entryhamza4");
input1=lookup_widget(objet_graphique,"entryhamza3");

input7=lookup_widget(objet_graphique,"combohamza");
input8=lookup_widget(objet_graphique,"entryhamza2");
strcpy(nom,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(prenom,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(poids,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(date,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(etat_medical,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input7)));
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input8)));
f=fopen("adh.txt","a+");
if(f!=NULL)
{
  fprintf(f,"%s %s %s %s %s %s\n",nom,prenom,cin,date,poids,etat_medical);
  fclose(f);
}




}

void
on_button5_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *nutri3;
GtkWidget *nutri6;
GtkWidget *treehamza1;
nutri3=lookup_widget(objet_graphique,"nutri3");
gtk_widget_destroy(nutri3);
nutri6=lookup_widget(objet_graphique,"nutri6");
nutri6=create_nutri6();
gtk_widget_show(nutri6);
treehamza1=lookup_widget(nutri6,"treehamza1");
afficher_personne(treehamza1);


}

/*void
on_button6_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *window4;
  GtkWidget *window3;
  window3=create_window3();
  window4=lookup_widget(objet_graphique,"window4");
  gtk_widget_hide(window4);
  gtk_widget_show(window3);

}*/
void
on_button9_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *nutri1;
  GtkWidget *nutri2;
  nutri1=create_nutri1();
  nutri2=lookup_widget(objet_graphique,"nutri2");
  gtk_widget_hide(nutri2);
  gtk_widget_show(nutri1);
}
void
on_button15_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *nutri6;
  GtkWidget *nutri3;
  nutri3=create_nutri3();
  nutri6=lookup_widget(objet_graphique,"nutri6");
  gtk_widget_hide(nutri6);
  gtk_widget_show(nutri3);
}
void
on_button8_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *nutri5;
  GtkWidget *nutri2;
  nutri5=create_nutri5();
  nutri2=lookup_widget(objet_graphique,"nutri2");
  gtk_widget_hide(nutri2);
  gtk_widget_show(nutri5);
}
void
on_button7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *nutri4;
  GtkWidget *nutri2;
  GtkWidget *treehamza;
  nutri4=create_nutri4();
  nutri2=lookup_widget(objet_graphique,"nutri2");
  gtk_widget_hide(nutri2);
  gtk_widget_show(nutri4);
  treehamza=lookup_widget(nutri4,"treehamza");
  afficher_dispo(treehamza);
}
void
on_button14_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *nutri4;
  GtkWidget *nutri2;
  nutri2=create_nutri2();
  nutri4=lookup_widget(objet_graphique,"nutri4");
  gtk_widget_hide(nutri4);
  gtk_widget_show(nutri2);
}
void
on_button13_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *nutri5;
  GtkWidget *nutri2;
  nutri2=create_nutri2();
  nutri5=lookup_widget(objet_graphique,"nutri5");
  gtk_widget_hide(nutri5);
  gtk_widget_show(nutri2);
}
void
on_button12_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *nutri3;
  GtkWidget *nutri2;
  nutri2=create_nutri2();
  nutri3=lookup_widget(objet_graphique,"nutri3");
  gtk_widget_hide(nutri3);
  gtk_widget_show(nutri2);

}



void
on_supprimer_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *input;
  GtkWidget *treehamza1;
  GtkWidget *nutri6;
  GtkWidget *output;
  char c[]="suppression";
  output=lookup_widget(objet_graphique,"labelhamza1");
  nutri6=(objet_graphique,"nutri6");
  int n=9;
  char cin[9];
  input=lookup_widget(objet_graphique,"entryhamza7");
  strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input)));
  supprimer(cin,n);
  treehamza1=lookup_widget(objet_graphique,"treehamza1");
  afficher_personne(treehamza1);
  gtk_label_set_text(GTK_LABEL(output),c);

}

void
on_modif_clicked                       (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{

  GtkWidget*input1;
  GtkWidget*input2;
  GtkWidget*input3;
  GtkWidget*input4;
  GtkWidget*input5;
  GtkWidget*input6;
  GtkWidget*output;
  FILE*f;
  char c[]="modification terminee";
  output=lookup_widget(objet_graphique,"label53");
  Personne p;
  input1=lookup_widget(objet_graphique,"entryhamza8");
  input2=lookup_widget(objet_graphique,"entryhamza9");
  input3=lookup_widget(objet_graphique,"entryhamza10");
  input4=lookup_widget(objet_graphique,"entryhamza11");
  input5=lookup_widget(objet_graphique,"entryhamza12");
  input6=lookup_widget(objet_graphique,"combohamza1");
  strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
  strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
  strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input3)));
  strcpy(p.date,gtk_entry_get_text(GTK_ENTRY(input4)));
  strcpy(p.poids,gtk_entry_get_text(GTK_ENTRY(input5)));
  strcpy(p.etat_medical,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input6)));
  modifier(p);
  gtk_label_set_text(GTK_LABEL(output),c);



}


void
on_anuuler_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *nutri6;
  GtkWidget *nutri7;
  GtkWidget *treehamza1;
  nutri6=create_nutri6();
  nutri7=lookup_widget(objet_graphique,"nutri7");
  gtk_widget_hide(nutri7);
  gtk_widget_show(nutri6);
treehamza1=lookup_widget(nutri6,"treehamza1");
afficher_personne(treehamza1);
}
void
on_modifier_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

  char cin[50];
  Personne p;
  FILE*f;
  GtkWidget *input;
  GtkWidget *nutri6;
  GtkWidget *nutri7;
  GtkWidget *output1;
  GtkWidget *output2;
  GtkWidget *output3;
  GtkWidget *output4;
  GtkWidget *output5;
  GtkWidget *output6;



  input=lookup_widget(objet_graphique,"entryhamza6");
  strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input)));
  nutri7=create_nutri7();
  nutri6=lookup_widget(objet_graphique,"nutri6");
  gtk_widget_hide(nutri6);
  gtk_widget_show(nutri7);
  output1=lookup_widget(nutri7,"entryhamza8");
  output2=lookup_widget(nutri7,"entryhamza9");
  output3=lookup_widget(nutri7,"entryhamza10");
  output4=lookup_widget(nutri7,"entryhamza11");
  output5=lookup_widget(nutri7,"entryhamza12");
  output6=lookup_widget(nutri7,"entryhamza13");
  f=fopen("adh.txt","a+");
  if(f!=NULL)
  {
    while(fscanf(f,"%s %s %s %s %s %s\n",p.nom,p.prenom,p.cin,p.date,p.poids,p.etat_medical
)!=EOF)
    {
      if(strcmp(cin,p.cin)==0)
      {
        gtk_entry_set_text(GTK_ENTRY(output1),p.nom);
        gtk_entry_set_text(GTK_ENTRY(output2),p.prenom);
        gtk_entry_set_text(GTK_ENTRY(output3),p.cin);
        gtk_entry_set_text(GTK_ENTRY(output4),p.date);
        gtk_entry_set_text(GTK_ENTRY(output5),p.poids);
        gtk_entry_set_text(GTK_ENTRY(output6),p.etat_medical);
      }
    }
    fclose(f);
  }


}

void
on_sup_disp_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *input;
  GtkWidget *treehamza;
  GtkWidget *nutri4;
  GtkWidget *output;
  char c[]="suppression";
  output=lookup_widget(objet_graphique,"labelhamza");
  nutri4=(objet_graphique,"nutri4");
  int n=9;
  char jour[9];
  input=lookup_widget(objet_graphique,"entryhamza5");
  strcpy(jour,gtk_entry_get_text(GTK_ENTRY(input)));
  supprimer1(jour,n);
  treehamza=lookup_widget(objet_graphique,"treehamza");
  afficher_dispo(treehamza);
  gtk_label_set_text(GTK_LABEL(output),c);
}


void
on_ajou_disp_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *nutri4;
  GtkWidget *dispo;
  dispo=create_dispo();
  nutri4=lookup_widget(objet_graphique,"nutri4");
  gtk_widget_hide(nutri4);
  gtk_widget_show(dispo);

}


void
on_retour_disp_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *nutri4;
  GtkWidget *dispo;
  GtkWidget *treehamza;
  nutri4=create_nutri4();
  dispo=lookup_widget(objet_graphique,"dispo");
  gtk_widget_hide(dispo);
  gtk_widget_show(nutri4);
  treehamza=lookup_widget(nutri4,"treehamza");
  afficher_dispo(treehamza);
}


void
on_ajout_dis_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char jour[30];char heure[30];
GtkWidget * input1;
GtkWidget *input2;
GtkWidget *dispo;
dispo=lookup_widget(objet_graphique,"dispo");
FILE *f;

input1=lookup_widget(objet_graphique,"combohamza2");
input2=lookup_widget(objet_graphique,"combohamza3");
strcpy(jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
strcpy(heure,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input2)));
f=fopen("disp.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s\n",jour,heure);
fclose(f);
}
}
